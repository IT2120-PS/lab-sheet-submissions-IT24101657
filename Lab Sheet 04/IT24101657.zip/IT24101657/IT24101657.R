setwd("C:\\Users\\it24101657\\Desktop\\IT24101657")
getwd()

data<-read.table("DATA 4.txt",header=TRUE,sep = " ")
fix(data)
attach (data)
# Boxplot
boxplot(X1, main = "Boxplot of Team Attendance", col = "skyblue")
boxplot(X2, main = "Boxplot of Team Salary", col = "orange")
boxplot(X3, main = "Boxplot of Years (Stadium Ownership)", col = "lightgreen")
# Histogram
hist(X1, main = "Histogram of Team Attendance", col = "skyblue")
hist(X2, main = "Histogram of Team Salary", col = "orange")
hist(X3, main = "Histogram of Years", col = "lightgreen")
# Stem and Leaf
stem(X1)
stem(X2)
stem(X3)
# Mean
mean(X1); mean(X2); mean(X3)
# Median
median(X1); median(X2); median(X3)
# Standard Deviation
sd(X1); sd(X2); sd(X3)
## Part (c)
## Getting five number summary along with mean value
summary(X1)
summary(X2)
summary(X3)
## Getting only five number summary for X1 variable
quantile(X1)
## Calling first Quartile of X1 using index value
quantile(X1)[2]
## Calling third Quartile of X1 using index value
quantile(X1)[4]
# IQR
IQR(X1)
IQR(X2)
IQR(X3)
## Part (3)
## Writing a function to find the mode of a given set of values
getMode <- function(v) {
  uniqVals <- unique(v)                    # Get unique values
  uniqVals[which.max(tabulate(match(v, uniqVals)))]  # Return value with max frequency
}
## Checking the function with the variable "Years" (X3)
getMode(X3)
table(x3)
max(counts)
## Part (4)
## Writing a function to find outliers in a numeric vector
findOutliers <- function(x) {
  Q1 <- quantile(x, 0.25)             # First quartile
  Q3 <- quantile(x, 0.75)             # Third quartile
  IQR_val <- Q3 - Q1                  # Interquartile Range
  lower_bound <- Q1 - 1.5 * IQR_val   # Lower limit
  upper_bound <- Q3 + 1.5 * IQR_val   # Upper limit
  outliers <- x[x < lower_bound | x > upper_bound]  # Values outside bounds
  return(outliers)
}
## Checking the function with the 3 variables
findOutliers(X1)   # Outliers in Team Attendance
findOutliers(X2)   # Outliers in Team Salary
findOutliers(X3)   # Outliers in Years
## Explanation on how each command inside the function works
## Following command is to calculate the interval for outliers
get.outliers <- function(z) {
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  ub <- q3 + 1.5 * iqr
  lb <- q1 - 1.5 * iqr
  ## Following command is to display the upper boundary and lower boundary of the interval
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  ## Checking the existence of outliers and Display the outliers if exists
  print(paste("Outliers:", paste(sort(z[z < lb | z > ub]), collapse = ", ")))
}
# Import dataset
branch_data <- read.table("Exercise.txt", header = TRUE)
# View first rows
head(branch_data)
str(branch_data)
## Step 3: Boxplot for Sales (assuming 'Sales' is a column in Exercise.txt)
boxplot(branch_data$Sales, main = "Boxplot of Sales", col = "lightblue", border = "darkblue")
# Interpretation (for your Word doc):
# If the box is symmetric → roughly normal distribution.
# If skewed left/right → distribution is skewed.
# Presence of dots → outliers.
# Five number summary
summary(branch_data$Team.Attendance..X1.)
# IQR
IQR(branch_data$Team.Attendance..X1.)
# Function to detect outliers
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_val <- IQR(x)
  lower_bound <- Q1 - 1.5 * IQR_val
  upper_bound <- Q3 + 1.5 * IQR_val
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}
# Check outliers in Years
find_outliers(branch_data$Years..X3.)

